#include "Window.hpp"

int main(){
    Window window;
    window.Window_void();
}