#ifndef WINDOW_HPP
#define WINDOW_HPP

#include <SFML/Graphics.hpp>
#include "Table.hpp"
#include <bits/stdc++.h>
using namespace std;

class Window{
public:
    void Window_void(){
        settings.antialiasingLevel=8;
        window.create(sf::VideoMode(width, height), "Drawing table", sf::Style::Close, settings);
        window.setPosition(sf::Vector2i(desktop_width/2-width/2, desktop_height/2-height/2));

        table.Table_void();

        while(window.isOpen()){
            while(window.pollEvent(event)){
                switch(event.type){
                    case sf::Event::Closed:
                        window.close();
                        break;
                }
                if(sf::Keyboard::isKeyPressed(sf::Keyboard::Escape))
                    window.close();
            }

            Mouse();

            window.clear();
            for(int i=0;i<19;i++)
                window.draw(table.line_down[i]);
            for(int i=0;i<29;i++)
                window.draw(table.line_up[i]);
            for(int i=0;i<20;i++){
                for(int j=0;j<30;j++)
                    window.draw(table.cubes[i][j]);
            }
            window.display();
        }
    }

    void Mouse(){
        if(sf::Mouse::isButtonPressed(sf::Mouse::Left)){
            for(int i=0;i<20;i++){
                for(int j=0;j<30;j++){
                    if(sf::Mouse::getPosition(window).x>=table.cubes[i][j].getPosition().x){
                        if(sf::Mouse::getPosition(window).x<=table.cubes[i][j].getPosition().x+40){
                            if(sf::Mouse::getPosition(window).y>=table.cubes[i][j].getPosition().y){
                                if(sf::Mouse::getPosition(window).y<=table.cubes[i][j].getPosition().y+40)
                                    table.cubes[i][j].setFillColor(sf::Color::Green);
                            }
                        }
                    }
                }
            }
        }
    }

    Table table;

    const int width=1229;
    const int height=819;

    const int desktop_width=sf::VideoMode::getDesktopMode().width;
    const int desktop_height=sf::VideoMode::getDesktopMode().height;

    sf::RenderWindow window;
    sf::Event event;
    sf::ContextSettings settings;
};

#endif // WINDOW_HPP