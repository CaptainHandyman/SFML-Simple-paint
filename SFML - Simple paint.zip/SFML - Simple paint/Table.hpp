#ifndef TABLE_HPP
#define TABLE_HPP

#include <SFML/Graphics.hpp>
#include <bits/stdc++.h>
using namespace std;

class Table{
public:
    void Table_void(){
        Line_down();
        Line_up();
        Cubes();
    }

    void Line_down(){
        for(int i=0;i<19;i++){
            line_down[i].setPosition(0, line_down_y);
            line_down[i].setSize(sf::Vector2f(1229, 1));
            line_down[i].setFillColor(sf::Color::Black);
            line_down_y+=41;
        }
    }

    void Line_up(){
        for(int i=0;i<29;i++){
            line_up[i].setPosition(line_up_x, 0);
            line_up[i].setSize(sf::Vector2f(1, 819));
            line_up[i].setFillColor(sf::Color::Black);
            line_up_x+=41;
        }
    }

    void Cubes(){
        for(int i=0;i<20;i++){
            for(int j=0;j<30;j++){
                cubes[i][j].setFillColor(sf::Color::White);
                cubes[i][j].setSize(sf::Vector2f(40, 40));
                cubes[i][j].setPosition(cubes_x, cubes_y);
                cubes_x+=41;
            }
            cubes_x=0;
            cubes_y+=41;
        }
    }

    int line_down_y=40;
    int line_up_x=40;

    int cubes_x=0;
    int cubes_y=0;

    sf::RectangleShape line_up[29];
    sf::RectangleShape line_down[19];
    sf::RectangleShape cubes[20][30];
};

#endif // TABLE_HPP